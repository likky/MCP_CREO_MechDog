#ifndef PROOBJECTS_H
#define PROOBJECTS_H

/* Creo Parametric TOOLKIT declarations for Pro<object> related data structures */

#include <ProToolkit.h>




/*
 * PTC Engineers: if you add a ProType, convert the T_ entry in ent_type.h
 * to refer to this type instead of a value.
 */

PRO_BEGIN_C_DECLS

#define PRO_UV_PARAM_UNUSED ((double) -2.0)

typedef enum pro_obj_types
{
  PRO_TYPE_DIR            =    -5,
  PRO_TYPE_INVALID        =    -2,
  PRO_TYPE_UNUSED         =    PRO_VALUE_UNUSED,   
  PRO_ASSEMBLY            =    1,
  PRO_PART                =    2,
  PRO_FEATURE             =    3,
  PRO_DRAWING             =    4,
  PRO_SURFACE             =    5,
  PRO_EDGE                =    6,
  PRO_3DSECTION           =    7,
  PRO_DIMENSION           =    8,
  PRO_2DSECTION           =   11,
  PRO_PAT_MEMBER          =   12,
  PRO_PAT_LEADER          =   13,
  PRO_XSEC                =   18,
  PRO_LAYOUT              =   19,
  PRO_AXIS                =   21,
  PRO_CSYS                =   25,
  PRO_REF_DIMENSION       =   28,
  PRO_GTOL                =   32,
  PRO_DWGFORM             =   33,
  PRO_SUB_ASSEMBLY        =   34,
  PRO_MFG                 =   37,
  PRO_SURF_FIN            =   42,
  PRO_QUILT               =   57,
  PRO_DATUM_TARGET        =   61,
  PRO_CURVE               =   62,
  PRO_POINT               =   66,
  PRO_NOTE                =   68,
  PRO_IPAR_NOTE           =   69,
  PRO_EDGE_START          =   71,
  PRO_EDGE_END            =   72,
  PRO_CRV_START           =   74,
  PRO_CRV_END             =   75,
  PRO_SYMBOL_INSTANCE     =   76,
  PRO_DRAFT_ENTITY        =   77,
  PRO_DRAFT_DATUM         =   79,
  PRO_DRAFT_GROUP         =   83,
  PRO_DRAW_TABLE          =   84,
  PRO_TABLE               =   84,
  PRO_COSMETIC            =   90,
  PRO_VIEW                =   92,
  PRO_CABLE               =   96,
  PRO_BODY                =   98,
  PRO_REPORT              =  105,
  PRO_MARKUP              =  116,
  PRO_LAYER               =  117,
  PRO_DIAGRAM             =  121,
  PRO_SKETCH_ENTITY       =  133,
  PRO_DATUM_TEXT          =  144,
  PRO_ENTITY_TEXT         =  145,
  PRO_DRAW_TABLE_CELL     =  147,
  PRO_PIPE_SEG            =  174,
  PRO_DATUM_PLANE         =  176,
  PRO_COMP_CRV            =  180,
  PRO_BND_TABLE           =  211,
  PRO_ANNOTATION_ELEM     =  219,
  PRO_SET_DATUM_TAG       =  220,
  PRO_ANNOT_ELEM_DRIVING_DIM =  224,
  PRO_PARAMETER           =  240,
  PRO_SILH_EDGE           =  256,
  /* Some functions may return a type value between PRO_SILH_EDGE and
     PRO_SILH_EDGE_MAX, if the surface has multiple silhouettes.  The
     meaning of this is that it is a silhouette of the surface given
     by id, and the silhouette index is (val - PRO_SILH_EDGE).  The
     only supported use of the type including the index is to use the
     same value when wanting to refer to the same silhouette, for
     example in a ProReference. */
  PRO_SILH_EDGE_MAX       =  299,
  PRO_DIAGRAM_OBJECT      =  305,
  PRO_DIAGRAM_WIRE        =  308,
  PRO_SIMP_REP            =  309,
  PRO_CE_DRAWING          =  315, /* For internal use */
  PRO_CE_SOLID            =  316, /* For internal use */
  PRO_DRW_SOLID           =  319, /* For internal use */
  PRO_WELD_PARAMS         =  371,
  PRO_SNAP_LINE           =  377,
  PRO_EXTOBJ              =  385,
  PRO_HYBRID_BODY         =  390,
  PRO_CSYS_AXIS_X         =  407,
  PRO_CSYS_AXIS_Y         =  408,
  PRO_CSYS_AXIS_Z         =  409,
  PRO_STYLE_STATE         =  460,
  PRO_VIS_STATE           =  461,
  PRO_COLOR_STATE         =  462,
  PRO_COMBINED_STATE      =  463,
  PRO_REFONLY_STATE       =  464,
  PRO_LAYER_STATE         =  465,
  PRO_SUBSET_STATE        =  466,
  PRO_APPEARANCE_STATE    =  467,
  PRO_EXPLD_STATE         =  500,
  PRO_CABLE_LOCATION      =  504,
  PRO_RELSET              =  533,
  PRO_ANALYSIS            =  555,
  PRO_SURF_CRV            =  556,
  PRO_SOLID_GEOMETRY      =  622,
  PRO_LOG_SRF             =  625,
  PRO_LOG_EDG             =  626,
  PRO_DESKTOP             =  627,
  PRO_SYMBOL_DEFINITION   =  628,
  PRO_FACET_SET           =  630,
  PRO_LOG_OBJECT          =  640,
  PRO_NEUTRAL_LAYER       =  641,
  PRO_IC_START            =  642,
  PRO_IC_END              =  643,
  PRO_EDGE_PNT            =  660,
  PRO_CRV_PNT             =  661,
  PRO_EDGE_END_PNT        =  662,
  PRO_ECAD_CONDUCTOR      =  704,
  PRO_CC_ASSEMBLY		  =  737,
  PRO_CC_PART			  =  740,
  PRO_NC_STEP_MODEL       =  804,
  PRO_NC_STEP_OBJECT      =  805,
  PRO_CATIA_MODEL         =  819,
  PRO_ANNOT_PLANE         =  849,
  PRO_CUSTOM_ANNOTATION   =  850,
  PRO_UG                  =  872,
  PRO_INVENTOR_PART       =  881,
  PRO_INVENTOR_ASSEM      =  882,
  PRO_SW_PART             =  886,
  PRO_SW_ASSEM            =  890,
  PRO_TOOL_MOTION         =  907,
  PRO_LOG_PNT             =  913,
  PRO_LOG_PLANE           =  914,
  PRO_LOG_CSYS            =  915,
  PRO_LOG_AXIS            =  916, 
  PRO_SURFACE_PNT         =  919,

  PRO_SURF_REGION_SIDE1   =  933,
  PRO_SURF_REGION_SIDE2   =  934,
  PRO_SRF_PLANE_PNT       =  935,
  PRO_CRV_SIDE1SRF_CNTR   =  937,
  PRO_CRV_SIDE2SRF_CNTR   =  938,

  PRO_SKETCH_CONSTRAINT   =  942,

  /* PRO_BODY_HNDL           =  973, */
  PRO_MODEL_BODIES        =  974,
  PRO_UDG                 =  975,  /* for internal use */
  PRO_CMPST_PLY_DEF       =  976,
  PRO_CMPST_PLY_ORDER     =  977,
  PRO_CMPST_PLY_PNT       =  978,
/*
   Following objects do not correspond to real proe database objects
*/
  PRO_CONTOUR             = 1000,
  PRO_GROUP               = 1001,
  PRO_UDF                 = 1002,
  PRO_FAMILY_TABLE        = 1003,
  PRO_CATIA_PART          = 1013,
  PRO_CATIA_PRODUCT       = 1014,
  PRO_CATIA_CGR           = 1015,

  /* Types used at Custom group only. */
  PRO_AUTO_GROUP_BODIES   = 4540, // T_AUTO_GROUP_BODIES, for internal use
  PRO_AUTO_GROUP_QUILTS   = 4541, // T_AUTO_GROUP_QUILTS, for internal use

  PRO_PATREL_FIRST_DIR    = 10018,
  PRO_PATREL_SECOND_DIR   = 10019,
  PRO_JAR_FILE            =  10020,

  PRO_SIMULATION_LOAD          = 11000,
  PRO_SIMULATION_WCS           = 11001,
  PRO_SIMULATION_BEAM          = 11004,
  PRO_SIMULATION_SHELL         = 11005,
  PRO_SIMULATION_BEAM_SECTION  = 11007,
  PRO_SIMULATION_BEAM_ORIENT   = 11008,
  PRO_SIMULATION_BEAM_RELEASE  = 11009,
  PRO_SIMULATION_SHELL_PROPS   = 11010,
  PRO_SIMULATION_MATL_ORIENT   = 11011,
  PRO_SIMULATION_SPRING        = 11012,
  PRO_SIMULATION_SPRING_PROPS  = 11013,
  PRO_SIMULATION_GAP           = 11014,
  PRO_SIMULATION_CONTACT       = PRO_SIMULATION_GAP,
  PRO_SIMULATION_MASS          = 11015,
  PRO_SIMULATION_MASS_PROPS    = 11016,
  PRO_SIMULATION_MESH_CNTRL    = 11017,
  PRO_SIMULATION_LOAD_SET      = 11018,
  PRO_SIMULATION_FUNCTION      = 11019,
  PRO_SIMULATION_CONSTRAINT    = 11020,
  PRO_SIMULATION_CONSTR_SET    = 11021,
  PRO_SIMULATION_SHELL_PAIR    = 11022,
  PRO_SIMULATION_CONNECTION    = 11023,
  PRO_SIMULATION_INTERFACE     = PRO_SIMULATION_CONNECTION,
  PRO_SIMULATION_WELD          = 11024,
  PRO_SIMULATION_MATL_ASSIGN   = 11025,
  PRO_SIMULATION_MEASURE       = 11026,
  PRO_SIMULATION_RUNNER        = 11027,  /*obsolete*/
  PRO_SIMULATION_ENTRANCE_PNT  = 11028,  /*obsolete*/
  PRO_SIMULATION_STIFF_COND    = 11029,
  PRO_SIMULATION_RIGID_LINK    = 11030,
  PRO_SIMULATION_WEIGHT_LINK   = 11033,
  PRO_SIMULATION_BOLT          = 11035,
  PRO_SIMULATION_CONT_REGION   = 11036,  /* obsolete */
  PRO_SIMULATION_OBJECT        = 11037,
  PRO_SIMULATION_ANALYSIS      = 11038,
  PRO_SIMULATION_CRACK         = 11039,
  PRO_SIMULATION_MATERIAL      = 11040,
  PRO_SIMULATION_SCOPE         = 11041,
  PRO_SIMULATION_INTEG_CONTACT = 11042,
  PRO_SIMULATION_INTEG_CONTACTPROP = 11043,
  PRO_SIMULATION_JOINT             = 11044,
  PRO_SIMULATION_JOINT_BEHAV       = 11045,
  PRO_SIMULATION_GD_CONNECTED_BODY = 11046,

  PRO_SIMULATION_VOLUME        = 11200,
  PRO_SIMULATION_PNT_PATTERN   = 11201,
  PRO_SIMULATION_FEAT_SEC      = 11202,
  PRO_SIMULATION_HP_FACE       = 11203,
  PRO_SIMULATION_HP_EDGE       = 11204,
  PRO_SIMULATION_HPE_BUNDLE    = 11205,
  PRO_SIMULATION_3D_NOTE       = 11206,
  PRO_SIMP_3D_LATTICE_ENT      = 11207,
  PRO_SIMULATION_USER_STUDY    = 11208, /* for internal use */
  PRO_SIMULATION_LOAD_CASE     = 11209, /* for internal use */

  /* Topology Optimimization objects */
  PRO_TOPOLOGYOPT_TOPO_REGION       = 11501,
  PRO_TOPOLOGYOPT_DESIGN_OBJ        = 11502,
  PRO_TOPOLOGYOPT_DESIGN_CONSTR     = 11503,
  PRO_TOPOLOGYOPT_STUDY             = 11504,

  PRO_MESH_MESH                = 11999,
  PRO_MESH_COMPONENT           = 12000,
  PRO_MESH_SURFACE             = 12002,
  PRO_MESH_EDGE                = 12004,
  PRO_MESH_CURVE               = 12005,
  PRO_MESH_VERTEX              = 12006,
  PRO_MESH_HARD_POINT          = 12008,
  PRO_MESH_NODE                = 12020,
  PRO_MESH_ELEMENT             = 12021,

  PRO_FEM_NEUTRAL_FILE         = 414,
  PRO_FEM_TM_FILE              = 12900,
  PRO_MECH_DIR                 = 12905,

  PRO_DISPOBJ                  = 13000,

  PRO_RP_MATERIAL              = 17001,

  PRO_RP_FUNCTION              = 17002,
  PRO_RP_MATERIAL_SET          = 17003, /* For internal use only */
  PRO_RP_MATERIAL_USAGE        = 17004,

  PRO_SKETCH_COSMETIC          = 20423,

  PRO_SEDGE_PART               = 20253,
  PRO_SEDGE_ASSEMBLY           = 20255,
  PRO_SEDGE_SHEETMETAL         = 20256, 

  PRO_QUERY                    = 45106,

  PRO_ARTWORK                  = 55100,  /* PI Artwork */

  PRO_TRY_OUT_HDR              = 60084,

  PRO_MDO_BODY                 = 70000,
  PRO_MDO_CAM_CONN             = 70003,
  PRO_MDO_GEAR_CONN            = 70004,
  PRO_MDO_SERVO_MOTOR          = 70005,
  PRO_MDO_FORCE_MOTOR          = 70006,
  PRO_MDO_SPRING               = 70007,
  PRO_MDO_DAMPER               = 70008,
  PRO_MDO_FORCE                = 70009,
  PRO_MDO_TORQUE               = 70010,
  PRO_MDO_ANALYSIS             = 70011,
  PRO_MDO_SNAPSHOT             = 70012,
  PRO_MDO_INIT_COND            = 70013,
  PRO_MDO_MEASURE              = 70014,
  PRO_MDO_JAS                  = 70015,
  PRO_MDO_GRAVITY              = 70016,
  PRO_MDO_MASSPROP             = 70017,
  PRO_MDO_SETTINGS             = 70018,
  PRO_MDO_CONN                 = 70019,
  PRO_MDO_CONN_AXIS            = 70020,    /* obsoleted */
  PRO_MDO_SLOT_CONN            = 70021,
  PRO_MDO_CONN_PARAM           = 70022,
  PRO_MDO_LOAD_XFER            = 70023,
  PRO_MDO_SLOT_AXIS            = 70024,
  PRO_MDO_CONN_AXIS_TR_1       = 70025,
  PRO_MDO_CONN_AXIS_TR_2       = 70026,
  PRO_MDO_CONN_AXIS_TR_3       = 70027,
  PRO_MDO_CONN_AXIS_ROT_1      = 70028,
  PRO_MDO_CONN_AXIS_ROT_2      = 70029,
  PRO_MDO_CONN_AXIS_ROT_3      = 70030,
  PRO_MDO_CONN_AXIS_EXT        = 70031,
  PRO_MDO_CONTACT_3D           = 70032,
  PRO_MDO_BELT                 = 70033,
  PRO_MDO_BUSHING_LD           = 70034,
  PRO_MDO_CONN_AXIS_CONE       = 70035,
  PRO_MDO_TERM_COND            = 70036,
  PRO_MDO_CHAIN                = 70037,
  PRO_MDO_CHAIN_AXIS           = 70038,
  
  PRO_PLACEMENT_SET            = 70100,

  PRO_COLSN_DATA               = 71000,

  PRO_ANIM_ANIMATION           = 73000,
  PRO_ANIM_SUB_ANIMATION       = 73001,
  PRO_ANIM_BODY                = 73002,
  PRO_ANIM_BODY_LOCK           = 73003,
  PRO_ANIM_CONN_STATUS         = 73004,
  PRO_ANIM_EVENT               = 73005,
  PRO_ANIM_DRIVER_INSTANCE     = 73006,
  PRO_ANIM_KFS                 = 73007,
  PRO_ANIM_KFS_INSTANCE        = 73008,
  PRO_ANIM_VIEW_AT_TIME        = 73009,
  PRO_ANIM_DISPLAY_AT_TIME     = 73010,
  PRO_ANIM_TRANS_AT_TIME       = 73011,
  PRO_ANIM_COMB                = 73012,
  PRO_ANIM_PI_KFS_INSTANCE     = 73013, /* obsoleted */
  PRO_ANIM_PI_INT_PT           = 73014, /* obsoleted */
  PRO_ANIM_PI_INT_AXIS         = 73015, /* obsoleted */
  PRO_ANIM_PI_INT_PLANE        = 73016, /* obsoleted */
  PRO_ANIM_EXPLD_KFS           = 73017,
  PRO_ANIM_EXPLD_KFS_INSTANCE  = 73018,
  PRO_ANIM_EXPLD_SUB_ANIMATION = 73019,
  PRO_ANIM_EXPLD_EVENT         = 73020,
  PRO_ANIM_MDO_EVENT           = 73021,
  PRO_ANIM_MDO_MOVIE           = 73022,
  PRO_ANIM_EXPLD_COMB          = 73023,
  PRO_ANIM_SNAP_COMB_KFS       = 73024,
  PRO_ANIM_SNAP_COMB_KFS_INSTANCE = 73025,
  PRO_ANIM_EXPLD_COMB_KFS       = 73026,
  PRO_ANIM_EXPLD_COMB_KFS_INSTANCE = 73027,

  PRO_LOG_CURVE                = 74150,
  PRO_LOG_COLLECTION           = 74151,
  PRO_LAYOUT_TAG               = 74152, /* for internal use */
  PRO_LAYOUT_NODE              = 74153, /* for internal use */
  PRO_LAYOUT_WP                = 74154, /* for internal use */

  PRO_DTM_CHK_PNT              = 74266,  /* for internal use */
  
  PRO_PSEG_START               = 74275,
  PRO_PSEG_END                 = 74276,

  PRO_QUILT_CONTOUR            = 74287,
  PRO_SENSOR                   = 74288,  /* for internal use */
  PRO_ECAD_CUT                 = 74290,

  PRO_RP_MANIKIN_SET           = 74345,

  PRO_SPOT_WELD_PNT            = 74359,

  PRO_ASM_LOG_SRF              = 74360,

  PRO_T_HARNESS                = 74361

} ProType;

typedef enum 
{

  PRO_DISP_REF_COL_ENT =        10001,
  PRO_DISP_INT_QLT_EDGE =       10002,
  PRO_DISP_SHTMETAL_SRF =       10003,
  PRO_DISP_CURVE_COL =          10004,
  PRO_DISP_DTM_PLN_POS =        10005,
  PRO_DISP_DTM_PLN_NEG =        10006,
  PRO_DISP_DTM_PLN_TAG =        10007,
  PRO_DISP_DTM_AXIS =           10008,
  PRO_DISP_DTM_AXIS_TAG =       10009,
  PRO_DISP_DTM_PNT =            10010,
  PRO_DISP_DTM_PNT_TAG =        10011,
  PRO_DISP_COORD_SYS =          PRO_CSYS,
  PRO_DISP_COORD_SYS_TAG =      10013,
  PRO_DISP_QLT_EDGE =           10014,
  PRO_DISP_SURF_MESH =          10015,
  PRO_DISP_DTM_CRV_TAG =        10024,
  PRO_DISP_CABLE =              PRO_CABLE,
  PRO_DISP_COSM_AR_PL_IN =      10101,         /* ECAD */
  PRO_DISP_COSM_AR_PL_OUT=      10102,         /* ECAD */
  PRO_DISP_COSM_AR_R_IN  =      10103,         /* ECAD */
  PRO_DISP_COSM_AR_R_OUT =      10104,         /* ECAD */
  PRO_DISP_COSM_AR_VIA   =      10105,         /* ECAD */
  PRO_DISP_COSM_AR_PL_REG =     10106,         /* ECAD */
  PRO_DISP_COSM_AR_FLX_REG =    10107,         /* ECAD */     
  PRO_DISP_ECAD_BOARD_TOP_SRF = 10108,         /* ECAD */
  PRO_DISP_ECAD_AR_USRDEF     = 10109,         /* ECAD */
  PRO_DISP_ECAD_CONDCTR_TOP_PINPADS     =  10110, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_TOP_VIAPADS     =  10111, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_TOP_ROUTES      =  10112, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_TOP_PLANES      =  10113, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_TOP_CONDFGR     =  10114, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_BOT_PINPADS     =  10115, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_BOT_VIAPADS     =  10116, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_BOT_ROUTES      =  10117, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_BOT_PLANES      =  10118, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_BOT_CONDFGR     =  10119, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_TOP_SILKSCREEN  =  10120, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_BOT_SILKSCREEN  =  10121, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_TOP_SOLDERMASK  =  10122, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_BOT_SOLDERMASK  =  10123, /* ECAD */
  PRO_DISP_ECAD_AR_SOLDERMASK           =  10124, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_TOP_PASTEMASK   =  10125, /* ECAD */
  PRO_DISP_ECAD_CONDCTR_BOT_PASTEMASK   =  10126, /* ECAD */
}
ProDisplayedType;

typedef enum pro_ent_type
{
    PRO_ENT_NONE =     -1,
    PRO_ENT_POINT =     1,
    PRO_ENT_LINE =      2, 
    PRO_ENT_ARC =       3,
    PRO_ENT_TXT =       6,
    PRO_ENT_ARROW =     8,
    PRO_ENT_CIRCLE =   10,
    PRO_ENT_SPLINE =   12,
    PRO_ENT_B_SPLINE = 19,
    PRO_ENT_ELLIPSE =  30,
    PRO_ENT_POLYGON =  40,
    PRO_ENT_CMP_CRV =  41,
    PRO_ENT_SRF_CRV =  56,
    PRO_ENT_PARAM_CRV = 62
} ProEnttype;

#define PRO_NO_BLOCK_FN_REGISTRY "ProNullFunc"

#define TK_BLOCK_MODEL_NONE              0
#define TK_BLOCK_MODEL_READONLY         (1 << 0)
#define TK_BLOCK_MODEL_COMPOSITE        (1 << 1)
#define TK_BLOCK_MODEL_EMBEDDED         (1 << 2)
#define TK_BLOCK_MODEL_ATB_WRAPPER      (1 << 3)
#define TK_BLOCK_MODEL_OBJ_NAME         (1 << 4)        //Cover flexible/inheritance 
#define TK_BLOCK_MODEL_EMBEDDED_NOT_ATB (1 << 5)

typedef enum pro_standard
{
    PROSTANDARD_ANSI = 1,
    PROSTANDARD_ISO  = 2
} ProStandard;

typedef void* ProObj;
typedef void* ProMdl;

typedef struct sld_part* ProSolid;
typedef struct sld_part* ProAssembly;
typedef struct sld_part* ProPart;
typedef struct drawing*  ProDrawing;

#define ProMdlToSolid(mdl)    ((ProSolid) mdl)
#define ProMdlToAssembly(mdl) ((ProAssembly) mdl)
#define ProMdlToPart(mdl)     ((ProPart) mdl)
#define ProMdlTohandle(mdl)   ((Prohandle) mdl)
#define ProSolidToMdl(sld)    ((ProMdl) sld)
#define ProAssemblyToMdl(asm) ((ProMdl) asm)
#define ProPartToMdl(prt)     ((ProMdl) prt)
#define ProhandleToMdl(hdl)   ((ProMdl) hdl)

typedef struct pro_model_item
{
  ProType  type;
  int      id;
  ProMdl owner;
} ProModelitem, ProGeomitem, ProExtobj, ProFeature, ProProcstep,
  ProSimprep, ProExpldstate, ProLayer, ProDimension, ProDtlnote,
  ProDtlsyminst, ProGtol, ProCompdisp, ProDwgtable, ProNote,
  ProAnnotationElem, ProAnnotation, ProAnnotationPlane, 
  ProSymbol, ProSurfFinish, ProMechItem, ProMaterialItem, ProCombstate,
  ProLayerstate, ProApprnstate, ProSolidBody, ProPly, ProTable;

typedef struct entity* ProPoint;
typedef struct entity* ProAxis;
typedef struct entity* ProCsys;
typedef struct entity* ProCurve;
typedef struct entity* ProCompcrv;

typedef struct geom* ProSurface;
typedef struct curve_header* ProEdge;
typedef struct contour* ProContour;
typedef struct quilt* ProQuilt;

typedef struct pro_model_item   *ProModelitemList;
typedef struct pro_model_item   *ProFeatlist;

typedef struct analysis *ProAnalysis;

/* opaque handle for text style */
typedef struct text_style *ProTextStyle;

typedef void*   ProUIImage;
typedef void   *ProAppData;
typedef ProError (*ProFunction)( );
/* 
   Purpose: This is a generic type for a function passed to Creo Parametric TOOLKIT 
            by an application.

   Input Arguments:
            Varies

   Output Arguments:
            Varies

   Return Values:
            Varies

   See Also:
        ProNotificationSet()
*/

#define PRO_NO_FUNCTION ((ProFunction) 0)


typedef enum proparamfrom { PRM_MODEL, PRM_ITEM } ProParamfrom;

typedef struct proparamowner
{
  ProParamfrom   type;
  union 
  {
    ProModelitem item;
    ProMdl     model;
  } who;
} ProParamowner;

typedef struct proparameter
{
  ProType       type;
  ProName       id;  
  ProParamowner owner;
} ProParameter;

typedef struct propattern
{
  ProType                 type;
  struct pat_struct      *pattern;
  ProMdl                  owner;
} ProPattern;

typedef struct propatmemb
{
  ProType                 type;
  struct pat_member      *patmemb;
  ProMdl                  owner;
} ProPatmemb;

/*---------------------------------------------------------------------------*/
                        
/*  Additional data structures that are NOT based on ProMdl and do NOT     */
/*  correspond to specific ProE objects.                                     */

/*---------------------------------------------------------------------------*/

typedef               int  ProIdTable[PRO_MAX_ASSEM_LEVEL];

typedef struct pro_comp_path 
{
   ProSolid    owner;
   ProIdTable  comp_id_table;
   int         table_num;
}  ProAsmcomppath;

typedef struct pro_asm_item 
{
   ProModelitem item;
   ProName      name; /* used for PRO_PARAMETER in 
                         this case item->type == PRO_PART or PRO_ASSEMBLY */
   ProAsmcomppath path;
}  ProAsmitem;


typedef struct pro_asm_path
{
   ProSolid    owner;
   int         *path; /* ProArray of int */
}  ProAsmpath;


typedef               double  ProUvParam[2];

typedef               double  ProVector[3];
typedef PRO_CONST_ARG double  ProConstVector[3];

typedef               double  ProMatrix[4][4];

typedef               float   ProMatrixFloat[4][4];

typedef               double  ProSelbox[2][3];

typedef               double  ProPoint2d[2];    /* obsolete; use Pro2dPnt */
typedef               double  Pro2dPnt[2]; /* 2-dimensional point */

typedef               float   Pro2dPntFloat[2];

typedef               double  ProPoint3d[3];    /* obsolete; use Pro3dPnt */
typedef               double  Pro3dPnt[3]; /* 3-dimensional point */

typedef               double  ProAngle; /* angular type (in radians) */
typedef               double  ProArea;

typedef               double  ProOutline[2][3];

typedef               double  ProLineEnvelope[4][3];
/* The order of coordinates in the envelope is:

         0 ----------------------------1
         |                             |
         2 ----------------------------3

This ordering of coordinates is preserved even if the text is mirrored or
applied at a rotation angle.
*/
 
typedef int *ProIntlist;

typedef struct 
{
   ProName       name;
   int           type;
}  ProExtobjClass;


typedef struct pro_collection *ProCollection;  
        

typedef ProError (*ProGeomitemFilter) (ProGeomitem *p_handle,
                                       ProAppData  app_data);
/*
   Purpose:  This is the  generic function for filtering a geomitem.

   Input Arguments:
      p_handle - The handle to a geomitem 
      app_data - The user data passed from <b>ProFeatureGeomitemVisit()</b>

   Output Arguments:
      None

   Return Values:
      PRO_TK_NO_ERROR      - Calls the visit function if not NULL
      PRO_TK_CONTINUE      - Skips to next ProGeomitem
*/

typedef ProError (*ProGeomitemAction) (ProGeomitem *p_handle,
                                       ProError    status,
                                       ProAppData  app_data);
/*
   Purpose:  This is the generic function for visiting a geomitem.

   Input Arguments:
      p_handle - The handle to the geomitem 
      status   - The status returned from the <i>ProGeomitemFilter</i>
                 function (if not NULL); otherwise, PRO_TK_NO_ERROR.
      app_data - The user data passed from <b>ProFeatureGeomitemVisit()</b>

   Output Arguments:
      None

   Return Values:
      PRO_TK_NO_ERROR      - Call the visit function (if not NULL).
      Other values         - Stop visiting.
*/

typedef ProError (*ProPointVisitAction) ( ProPoint   p_point,
                                          ProError   status,
                                          ProAppData app_data );
/*
   Purpose:  This is the generic function for visiting a datum point.

   Input Arguments:
       p_point  -  The datum point handle
       status   -  The status
       app_data -  The application data passed to the function 
                   <b>ProAsmcomppathDispPointVisit()</b>

   Output Arguments:
       None

   Return Values:
       PRO_TK_NO_ERROR - Continue visiting.
       Any other value - Stop visiting.
*/

typedef ProError (*ProPointFilterAction) ( ProPoint   p_point,
                                           ProAppData app_data );

/*
   Purpose:  This is the generic function for filtering a datum point.

   Input Arguments:
       p_point  -  The datum point handle
       app_data -  The application data passed to the function 
                   <b>ProAsmcomppathDispPointVisit()</b>

   Output Arguments:
       None

   Return Values:
       PRO_TK_CONTINUE - Skip visiting this datum point and go to the next.
       Other           - Call the visit action for this datum point. The
                         return value is passed as input to the visit action.
*/

typedef ProError (*ProCurveVisitAction) ( ProCurve   p_curve,
                                          ProError   status,
                                          ProAppData app_data );
/*
   Purpose:  This is the generic function for visiting a datum curve.

   Input Arguments:
       p_curve  -  The datum curve handle
       status   -  The status
       app_data -  The application data passed to the function 
                   <b>ProAsmcomppathDispCurveVisit()</b>

   Output Arguments:
       None

   Return Values:
       PRO_TK_NO_ERROR - Continue visiting.
       Any other value - Stop visiting.
*/

typedef ProError (*ProCurveFilterAction) ( ProCurve   p_curve,
                                           ProAppData app_data );

/*
   Purpose:  This is the generic function for filtering a datum curve.

   Input Arguments:
       p_curve  -  The datum curve handle
       app_data -  The application data passed to the function 
                   <b>ProAsmcomppathDispCurveVisit()</b>

   Output Arguments:
       None

   Return Values:
       PRO_TK_CONTINUE - Skip visiting this datum curve and go to the next.
       Other           - Call the visit action for this datum curve. The
                         return value is passed as input to the visit action.
*/
 
typedef ProError (*ProCsysVisitAction) ( ProCsys  p_csys,
                                         ProError status,
                                         ProAppData app_data );
/*
   Purpose:  This is the generic function for visiting a coordinate system.

   Input Arguments:
       p_csys   -  The coordinate system handle
       status   -  The status
       app_data -  The application data passed to the function 
                   <b>ProSolidCsysVisit()</b>

   Output Arguments:
       None

   Return Values:
       PRO_TK_NO_ERROR - Continue visiting.
       Any other value - Stop visiting.
*/

typedef ProError (*ProCsysFilterAction) ( ProCsys  p_csys,
                                          ProAppData app_data );

/*
   Purpose:  This is the generic function for filtering a coordinate system.

   Input Arguments:
       p_csys   -  The coordinate system handle
       app_data -  The application data passed to the function 
                   <b>ProSolidCsysVisit()</b>

   Output Arguments:
       None

   Return Values:
       PRO_TK_CONTINUE - Skip visiting this coordinate system and go to 
                         the next.
       Other           - Call the visit action for this coordinate system. The
                         return value is passed as input to the visit action.
*/

typedef ProError (*ProQuiltVisitAction) ( ProQuilt p_quilt,
                                          ProError status,
                                          ProAppData app_data );
/*
   Purpose:  This is the generic function for visiting a quilt.

   Input Arguments:
       p_quilt  -  The quilt handle
       status   -  The status
       app_data -  The application data passed to the function 
                   <b>ProSolidQuiltVisit()</b>

   Output Arguments:
       None

   Return Values:
       PRO_TK_NO_ERROR - Continue visiting.
       Any other value - Stop visiting.
*/

typedef ProError (*ProQuiltFilterAction) ( ProQuilt p_quilt,
                                           ProAppData app_data );

/*
   Purpose:  This is the generic function for filtering a quilt.

   Input Arguments:
       p_quilt  -  The quilt handle
       app_data -  The application data passed to the function 
                   <b>ProSolidQuiltVisit()</b>

   Output Arguments:
       None

   Return Values:
       PRO_TK_CONTINUE - Skip visiting this quilt and go to the next quilt.
       Other           - Call the visit action for this quilt. The return
                         value is passed as input to the visit action.
*/

LIB_COREUTILS_API ProError ProAsmpathProarrayFree(ProAsmpath **p_asm_pathes);
/*
    Purpose:     Frees ProArray of ProAsmpath.

    Input Arguments:
        p_asm_pathes - ProArray of ProAsmpath.

    Output Arguments:
        none

    Return Values:
        PRO_TK_NO_ERROR - The function successfully freed the data.
        PRO_TK_BAD_INPUTS  - p_asm_pathes is NULL.
*/

PRO_END_C_DECLS

#endif  /* PROOBJECTS_H */
