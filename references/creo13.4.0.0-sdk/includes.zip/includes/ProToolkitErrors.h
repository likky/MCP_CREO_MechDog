#ifndef PROTOOLKITERRORS_H
#define PROTOOLKITERRORS_H



#include <ProANSI.h>

PRO_BEGIN_C_DECLS

typedef enum ProErrors  
{
  PRO_TK_NO_ERROR		=  0,
  PRO_TK_GENERAL_ERROR	    	= -1,
  PRO_TK_BAD_INPUTS		= -2,
  PRO_TK_USER_ABORT		= -3,
  PRO_TK_E_NOT_FOUND		= -4,
  PRO_TK_E_FOUND		= -5,
  PRO_TK_LINE_TOO_LONG		= -6,
  PRO_TK_CONTINUE		= -7,
  PRO_TK_BAD_CONTEXT		= -8,
  PRO_TK_NOT_IMPLEMENTED	= -9,
  PRO_TK_OUT_OF_MEMORY		= -10,
  PRO_TK_COMM_ERROR		= -11, /* communication error */
  PRO_TK_NO_CHANGE		= -12,
  PRO_TK_SUPP_PARENTS		= -13,
  PRO_TK_PICK_ABOVE		= -14,
  PRO_TK_INVALID_DIR		= -15,
  PRO_TK_INVALID_FILE		= -16,
  PRO_TK_CANT_WRITE		= -17,
  PRO_TK_INVALID_TYPE		= -18,
  PRO_TK_INVALID_PTR		= -19,
  PRO_TK_UNAV_SEC		= -20,
  PRO_TK_INVALID_MATRIX		= -21,
  PRO_TK_INVALID_NAME		= -22,
  PRO_TK_NOT_EXIST		= -23,
  PRO_TK_CANT_OPEN		= -24,
  PRO_TK_ABORT			= -25,
  PRO_TK_NOT_VALID		= -26,
  PRO_TK_INVALID_ITEM		= -27,
  PRO_TK_MSG_NOT_FOUND		= -28,
  PRO_TK_MSG_NO_TRANS		= -29,
  PRO_TK_MSG_FMT_ERROR		= -30,
  PRO_TK_MSG_USER_QUIT		= -31,
  PRO_TK_MSG_TOO_LONG		= -32,
  PRO_TK_CANT_ACCESS		= -33,
  PRO_TK_OBSOLETE_FUNC		= -34,
  PRO_TK_NO_COORD_SYSTEM	= -35,
  PRO_TK_E_AMBIGUOUS		= -36,
  PRO_TK_E_DEADLOCK		= -37,
  PRO_TK_E_BUSY			= -38,
  PRO_TK_E_IN_USE		= -39,
  PRO_TK_NO_LICENSE		= -40,
  PRO_TK_BSPL_UNSUITABLE_DEGREE = -41,
  PRO_TK_BSPL_NON_STD_END_KNOTS = -42,
  PRO_TK_BSPL_MULTI_INNER_KNOTS = -43,
  PRO_TK_BAD_SRF_CRV		= -44,
  PRO_TK_EMPTY                  = -45,
  PRO_TK_BAD_DIM_ATTACH         = -46,
  PRO_TK_NOT_DISPLAYED          = -47,
  PRO_TK_CANT_MODIFY            = -48,
  PRO_TK_CHECKOUT_CONFLICT      = -49,
  PRO_TK_CRE_VIEW_BAD_SHEET     = -50,
  PRO_TK_CRE_VIEW_BAD_MODEL     = -51,
  PRO_TK_CRE_VIEW_BAD_PARENT    = -52,
  PRO_TK_CRE_VIEW_BAD_TYPE      = -53,
  PRO_TK_CRE_VIEW_BAD_EXPLODE   = -54,
  PRO_TK_UNATTACHED_FEATS       = -55,
  PRO_TK_REGEN_AGAIN            = -56,
  PRO_TK_DWGCREATE_ERRORS       = -57,
  PRO_TK_UNSUPPORTED            = -58,
  PRO_TK_NO_PERMISSION          = -59,
  PRO_TK_AUTHENTICATION_FAILURE = -60,
  PRO_TK_OUTDATED               = -61,
  PRO_TK_INCOMPLETE             = -62,
  PRO_TK_CHECK_OMITTED          = -63,
  PRO_TK_MAX_LIMIT_REACHED      = -64,
  PRO_TK_OUT_OF_RANGE           = -65, 
  PRO_TK_CHECK_LAST_ERROR	= -66,
  /*
    NOTE: PRO_TK_NO_PLM_LICENSE error added to handle lack of PTC Mechanical Design I/II licenses
  */
  PRO_TK_NO_PLM_LICENSE         = -67,
  PRO_TK_INCOMPLETE_TESS        = -68,
  PRO_TK_MULTIBODY_UNSUPPORTED  = -69,
  PRO_TK_BROWSER_UNAVAILABLE    = -70,
  PRO_TK_DLL_LOAD_ERROR         = -71,
  PRO_TK_SUPPRESSED             = -72,
  

  /*
    NOTE: the errors below are reserved for the Creo Toolkit API. Applications
    should never return these errors.
  */
  PRO_TK_APP_CREO_BARRED	= -88,
  PRO_TK_APP_TOO_OLD            = -89,
  PRO_TK_APP_BAD_DATAPATH       = -90,
  PRO_TK_APP_BAD_ENCODING       = -91,
  PRO_TK_APP_NO_LICENSE 	= -92,
  PRO_TK_APP_XS_CALLBACKS	= -93,
  PRO_TK_APP_STARTUP_FAIL	= -94,
  PRO_TK_APP_INIT_FAIL	        = -95,
  PRO_TK_APP_VERSION_MISMATCH   = -96,
  PRO_TK_APP_COMM_FAILURE	= -97,
  PRO_TK_APP_NEW_VERSION	= -98,
  PRO_TK_APP_UNLOCK	        = -99,
  PRO_TK_APP_JLINK_NOT_ALLOWED  = -100
  
}  ProError, ProErr;    /* most commonly used Creo Parametric TOOLKIT error statuses */

PRO_END_C_DECLS

#endif
